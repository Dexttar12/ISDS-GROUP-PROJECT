﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISDS309_Fa24_S03_Project_1
{
    public partial class formReceipt : Form
    {
        string[,] movies = new string[,]
      {
             { "1", "Avatar 2", "Sci-Fi Adventure", "8", "2022" },
              { "2", "Oppenheimer", "Historical Drama", "9", "2023" },
             { "3", "Barbie", "Comedy/Fantasy", "7", "2023" },
                { "4", "Shrek", "Comedy/Adventure", "8", "2001" },
                { "5", "Croods", "Comedy/Animation", "7", "2013" }
      };
        private string username1;
        private string nameUser;
        private string resultMessage2;
        private int movieIndex;
        private int totalCost;
        private bool ticketPurchased;


        public formReceipt(string resultMessage2, int movieIndex, int totalCost, string nameUser,string username1,bool ticketPurchased)
        {
            InitializeComponent();
            this.resultMessage2 = resultMessage2;
            this.movieIndex = movieIndex;
            this.totalCost = totalCost;
            this.username1 = username1;
            this.nameUser = nameUser;
            this.ticketPurchased= ticketPurchased;

            lblTotalCostResults.Text = "$"+totalCost.ToString();
            lblMovieResult.Text = movies[movieIndex, 1];
        }

        private void formReceipt_Load(object sender, EventArgs e)
        {
            lblCostResults.Text = resultMessage2;
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {

            formMainMenu mainMenuForm = new formMainMenu(nameUser, username1, resultMessage2, movieIndex, totalCost, ticketPurchased);
            formMovieLog MovieLogForm = new formMovieLog(resultMessage2, movieIndex, totalCost, ticketPurchased);
            mainMenuForm.Show();
            this.Hide();
        }
    }
}
