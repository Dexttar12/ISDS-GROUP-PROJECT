namespace ISDS309_Fa24_S03_Project_1
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string resultMessage2 = "Some message";
            int movieIndex = 1;  // Example movie index
            int totalCost = 20;  // Example total cost
            bool ticketPurchased = false;
            Application.Run(new formMovieLog(resultMessage2, movieIndex, totalCost, ticketPurchased));
        }
    }
}