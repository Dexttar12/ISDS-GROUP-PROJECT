﻿namespace ISDS309_Fa24_S03_Project_1
{
    partial class formReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblDisplayReceipt = new Label();
            lblDisplayMovie = new Label();
            lblMovieResult = new Label();
            lblCostResults = new Label();
            lblDisplayTotalCost = new Label();
            lblTotalCostResults = new Label();
            btnMainMenu = new Button();
            SuspendLayout();
            // 
            // lblDisplayReceipt
            // 
            lblDisplayReceipt.AutoSize = true;
            lblDisplayReceipt.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDisplayReceipt.Location = new Point(113, 8);
            lblDisplayReceipt.Name = "lblDisplayReceipt";
            lblDisplayReceipt.Size = new Size(77, 25);
            lblDisplayReceipt.TabIndex = 0;
            lblDisplayReceipt.Text = "Receipt";
            // 
            // lblDisplayMovie
            // 
            lblDisplayMovie.AutoSize = true;
            lblDisplayMovie.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDisplayMovie.Location = new Point(84, 58);
            lblDisplayMovie.Name = "lblDisplayMovie";
            lblDisplayMovie.Size = new Size(62, 21);
            lblDisplayMovie.TabIndex = 1;
            lblDisplayMovie.Text = "Movie:";
            // 
            // lblMovieResult
            // 
            lblMovieResult.AutoSize = true;
            lblMovieResult.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMovieResult.Location = new Point(148, 58);
            lblMovieResult.Name = "lblMovieResult";
            lblMovieResult.Size = new Size(59, 21);
            lblMovieResult.TabIndex = 2;
            lblMovieResult.Text = "Barbie";
            // 
            // lblCostResults
            // 
            lblCostResults.AutoSize = true;
            lblCostResults.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCostResults.Location = new Point(9, 97);
            lblCostResults.Name = "lblCostResults";
            lblCostResults.Size = new Size(0, 21);
            lblCostResults.TabIndex = 4;
            // 
            // lblDisplayTotalCost
            // 
            lblDisplayTotalCost.AutoSize = true;
            lblDisplayTotalCost.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDisplayTotalCost.Location = new Point(42, 227);
            lblDisplayTotalCost.Name = "lblDisplayTotalCost";
            lblDisplayTotalCost.Size = new Size(89, 21);
            lblDisplayTotalCost.TabIndex = 5;
            lblDisplayTotalCost.Text = "Total Cost:";
            // 
            // lblTotalCostResults
            // 
            lblTotalCostResults.AutoSize = true;
            lblTotalCostResults.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalCostResults.Location = new Point(133, 227);
            lblTotalCostResults.Name = "lblTotalCostResults";
            lblTotalCostResults.Size = new Size(57, 21);
            lblTotalCostResults.TabIndex = 6;
            lblTotalCostResults.Text = "label1";
            // 
            // btnMainMenu
            // 
            btnMainMenu.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMainMenu.Location = new Point(320, 8);
            btnMainMenu.Name = "btnMainMenu";
            btnMainMenu.Size = new Size(91, 25);
            btnMainMenu.TabIndex = 7;
            btnMainMenu.Text = "Main Menu";
            btnMainMenu.UseVisualStyleBackColor = true;
            btnMainMenu.Click += btnMainMenu_Click;
            // 
            // formReceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(423, 501);
            Controls.Add(btnMainMenu);
            Controls.Add(lblTotalCostResults);
            Controls.Add(lblDisplayTotalCost);
            Controls.Add(lblCostResults);
            Controls.Add(lblMovieResult);
            Controls.Add(lblDisplayMovie);
            Controls.Add(lblDisplayReceipt);
            Name = "formReceipt";
            Text = "Form5";
            Load += formReceipt_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblDisplayReceipt;
        private Label lblDisplayMovie;
        private Label lblMovieResult;
        private Label lblCostResults;
        private Label lblDisplayTotalCost;
        private Label lblTotalCostResults;
        private Button btnMainMenu;
    }
}