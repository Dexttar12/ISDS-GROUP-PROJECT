﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ISDS309_Fa24_S03_Project_1
{
    public partial class formMainMenu : Form
    {
        private string nameUser;
        private string username1;
        private string resultMessage2;
        private int movieIndex;
        private int totalCost;
        private bool ticketPurchased;
        public formMainMenu(string nameUser, string username1, string resultMessage2, int movieIndex, int totalCost,bool ticketPurchased)
        {
            InitializeComponent();
            this.resultMessage2 = resultMessage2;
            this.movieIndex = movieIndex;
            this.totalCost = totalCost;
            this.username1 = username1;
            this.nameUser = nameUser;
            this.ticketPurchased = ticketPurchased;

        }

        //display welcome message
        private void formMainMenu_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome " + nameUser + "!";
        }

        //if buy ticket button is clicked, it moves form to buying form
        private void btnBuyTicket_Click(object sender, EventArgs e)
        {
            formMovieTickets MovieTicketsform = new formMovieTickets(username1, nameUser);
            MovieTicketsform.Show();
            this.Close();
        }

        //if log out button is clicked, it logs out and restarts the process
        private void btnLogOut_Click(object sender, EventArgs e)
        {
            formMovieLog MovieLogform = new formMovieLog(resultMessage2,movieIndex,totalCost, ticketPurchased);
            MovieLogform.Show();
            this.Hide();
        }

        private void btnReciept_Click(object sender, EventArgs e)
        {
            if (ticketPurchased == false)
            {
                MessageBox.Show("You have not purchased a ticket yet");
            }
            else 
            {
                formReceipt Receiptform = new formReceipt(resultMessage2, movieIndex, totalCost, username1, nameUser, ticketPurchased);
                Receiptform.Show();
                this.Hide();
            }
            
            
        }
    }
}
