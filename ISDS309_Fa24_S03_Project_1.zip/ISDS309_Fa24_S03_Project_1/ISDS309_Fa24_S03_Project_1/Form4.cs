﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ISDS309_Fa24_S03_Project_1
{
    public partial class formShoppingCart : Form
    {
        

        private bool ticketPurchased = false;
        string[,] movies = new string[,]
       {
             { "1", "Avatar 2", "Sci-Fi Adventure", "8", "2022" },
              { "2", "Oppenheimer", "Historical Drama", "9", "2023" },
             { "3", "Barbie", "Comedy/Fantasy", "7", "2023" },
                { "4", "Shrek", "Comedy/Adventure", "8", "2001" },
                { "5", "Croods", "Comedy/Animation", "7", "2013" }
       };
        private string username1;
        private string resultMessage2;
        private string nameUser;
        private int totalCost;
        private int movieIndex;
        public formShoppingCart(int movieIndex, int seatDolby, int seats3D, int seatReg, int totalCost, string username1, string resultMessage2,string nameUser)
        {
            InitializeComponent();

            lblInsertMovie.Text = movies[movieIndex, 1];
            lblNumDolby.Text = seatDolby.ToString();
            lblNum3D.Text = seats3D.ToString();
            lblNumReg.Text = seatReg.ToString();
           lblInsertTotal.Text = totalCost.ToString();
          
            this.movieIndex = movieIndex;
            this.totalCost = totalCost;
            this.resultMessage2 = resultMessage2;
            this.username1 = username1;
            this.nameUser = nameUser;   
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            string creditCardInput = txtbxInsertCreditCard.Text;
            string userName = txtbxUserName.Text.Trim();
            string payComplete = "Payment Complete!";

            if (creditCardInput.Length != 11)
            {
                lblCreditMessage.Text = "Your credit card number does not contain 11 characters";
            }
                else if (!creditCardInput.All(char.IsDigit))
            {
                lblCreditMessage.Text = "Your credit card number must only contain numeric characters";
            }
            else if (string.IsNullOrEmpty(userName))
            {
                MessageBox.Show("Please insert your username"); 
            }
             else if (userName.Trim() != username1.Trim())
            {
                MessageBox.Show("Please insert your correct username");
            }
                else
            {
                lblCreditMessage.Text = "Your Credit Card Number contains 11 digits";
                DialogResult receiveReceipt = MessageBox.Show(payComplete, "Receipt", MessageBoxButtons.OK);

                if (receiveReceipt == DialogResult.OK)
                {
                    ticketPurchased = true;

                    string logMessage = $"Transaction Completed for {userName} ({username1}) - " +
                               $"Movie: {movies[movieIndex, 1]} - " +
                               $"Seats - Dolby: {lblNumDolby.Text}, 3D: {lblNum3D.Text}, Regular: {lblNumReg.Text} - " +
                               $"Total: ${lblInsertTotal.Text}";
                    Logger.Log(logMessage);

                    formReceipt Receiptform = new formReceipt(resultMessage2,movieIndex,totalCost, username1, nameUser, ticketPurchased);
                    Receiptform.Show();

                    GenerateReceipt();

                    this.Close();

                   
                }

            }

        }
        private void GenerateReceipt()
        {
           string receiptFileName = $"Receipt_{username1}_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string receiptContent = $"Receipt for {nameUser} ({username1})\n" +
                                     $"Movie: {movies[movieIndex, 1]} ({movies[movieIndex, 2]})\n" +
                                    $"Seats:\n" +
                                     $"- Dolby: {lblNumDolby.Text}\n" +
                                    $"- 3D: {lblNum3D.Text}\n" +
                                    $"- Regular: {lblNumReg.Text}\n" +
                                      $"Total Cost: ${lblInsertTotal.Text}\n" +
                                    $"Date: {DateTime.Now:MMMM dd, yyyy}\n" +
                                    $"Thank you for your purchase!";

            try
            {
               
                File.WriteAllText(receiptFileName, receiptContent);
                MessageBox.Show($"Receipt saved as {receiptFileName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving the receipt: {ex.Message}");
            }
        }

        private void btnReviewOrder_Click(object sender, EventArgs e)
        {
            formMovieTickets MovieTicketsform = new formMovieTickets(username1, nameUser);
            MovieTicketsform.Show();
            this.Close();
        }


    }
}
